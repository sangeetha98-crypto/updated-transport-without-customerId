package com.example.demo.controller;



//import java.text.SimpleDateFormat;
//import java.util.Date;
//import java.util.List;
//import java.util.Properties;
//
//import javax.websocket.Session;
//import java.io.FileOutputStream;
//import java.io.IOException;
//import java.text.ParseException;
//import java.text.SimpleDateFormat;
//import java.util.Date;
import java.util.List;
//import java.util.Properties;



import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.entity.Customer;
import com.example.demo.entity.Transport;
import com.example.demo.model.CustomerService;
import com.example.demo.model.TransportService;

import oracle.jdbc.driver.Message;

@RestController
@CrossOrigin(origins = {"http://localhost:4200", "*"})
public class TransportController {
 @Autowired
	private TransportService ts;
 @Autowired
  CustomerService cs;
  
 @PostMapping("/transport")
 public Transport addTransport(@RequestBody Transport transport) 
{
	 return ts.create(transport);
 }
// 
// @PostMapping("/transport")
// public Transport addTransport(@RequestParam("transportId")String transportId,@RequestParam("customerId")String customerId,@RequestParam("vehicleType")String vehicleType,@RequestParam("driverName")String driverName,@RequestParam("driverPhoneNo")String driverPhoneNo )
// {
//	 Customer customer = cs.read(customerId);
//	 Transport transport= new Transport();
//	 transport.setTransportId(transportId);
//	 transport.setCustomer(customer);
//	 transport.setVehicleType(vehicleType);
//	 transport.setDriverName(driverName);
//	 transport.setDriverPhoneNo(driverPhoneNo);
//	 return ts.create(transport);
// }
// 
// 
 
 @GetMapping("/transport")
 public List<Transport> getAllTransport()
 {
	 return ts.read();
 }
 @GetMapping("/transport/{transportId}")
 public Transport findTransportById(@PathVariable("transportId") String transportId)
 {
 
return ts.read(transportId) ;
 }
 
 
 
 @PutMapping("/transport/")
 public Transport modifyTransport(@RequestBody Transport transport) 
 {
	 return ts.update(transport);
	 
 }
  
//  @PutMapping("/transport/")
//  public Transport modifyTransport(@RequestParam("transportId")String transportId,@RequestParam("customerId")String customerId,@RequestParam("vehicleType")String vehicleType,@RequestParam("driverName")String driverName,@RequestParam("driverPhoneNo")String driverPhoneNo ) 
//  {
//	  Customer customer = cs.read(customerId);
//		 Transport transport= new Transport();
//		 transport.setTransportId(transportId);
//		 transport.setCustomer(customer);
//		 transport.setVehicleType(vehicleType);
//		 transport.setDriverName(driverName);
//		 transport.setDriverPhoneNo(driverPhoneNo);
// 	 return ts.update(transport);
// 	 
//  }
  @DeleteMapping("/transport/{transportId}")
  
		  public void  removeTransport(@PathVariable("transportId") String transportId)
		  {
               ts.delete(transportId);
		  }
}



